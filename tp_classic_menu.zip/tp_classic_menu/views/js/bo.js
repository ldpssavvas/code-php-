$(document).ready(function()
{
	$(document).on('click','.replace_select', function (e)
	{
    	$(this).toggleClass('active');
	});

	$('.view_category').on('click', function(e)
  	{
    	$('.replace_select').toggleClass('active');

    	e.preventDefault();
    	e.stopPropagation();

    	var category = $(this).attr('data-value');
        form = $('.products_form');
        products_list = $('.products_list');
        loader = $('.loader');
        category_view_link = form.attr('data-pure-link') + '&action=ajaxProcessCategoryView&cid=' + category;

    	//We display the loader animation
    	loader.toggleClass('hidden');

    	//We update the category view
    	products_list.load(category_view_link, function()
    	{
      		//We update the data-current-category attribute
      		form.attr('data-current-category',category);

      		//We hide the loader
      		loader.addClass('hidden');
    	});
  	});
});