<?php

/**
 * @author     Konstantinos A. Kogkalidis <konstantinos@tapanda.gr>
 * @copyright  2018 tapanda.gr <https://tapanda.gr/el/>
 * @license    Single website per license
 * @version    1.0
 * @since      1.0
 */

require_once _PS_MODULE_DIR_ . 'tp_skroutz_spy/tp_skroutz_spy.php';

class SkroutzSpyLink extends ObjectModel
{
    public $id_tp_skroutz_link;
    public $link;
    public $product_id;
    public $ipa;

	public static $definition = array(
        'table'		=> 'tp_skroutz_link',
        'primary'	=> 'id_tp_skroutz_link',
        'fields'	=> array(
            'link' => array(
                'type' => self::TYPE_STRING,
                'validate' => 'isUrl',
                'required' => true
            ),
            'product_id' => array(
                'type' => self::TYPE_INT,
                'validate' => 'isUnsignedInt'
            ),
            'ipa' => array(
                'type' => self::TYPE_INT,
                'validate' => 'isUnsignedInt'
            )
        )
    );
}
