<?php

/**
 * @author     Konstantinos A. Kogkalidis <konstantinos@tapanda.gr>
 * @copyright  2018 tapanda.gr <https://tapanda.gr/el/>
 * @license    Single website per license
 * @version    1.0
 * @since      1.0
 */

require_once _PS_MODULE_DIR_ . 'tp_classic_menu/tp_classic_menu.php';

class ClassicMenuCategory extends ObjectModel
{
    public $id_tp_classic_menu_category;
    public $category_id;
    public $position;

	public static $definition = array(
        'table'		=> 'tp_classic_menu_category',
        'primary'	=> 'id_tp_classic_menu_category',
        'fields'	=> array(
            'category_id' => array(
                'type' => self::TYPE_INT,
                'validate' => 'isUnsignedInt',
                'required' => true
            ),
            'position' => array(
                'type' => self::TYPE_INT,
                'validate' => 'isUnsignedInt',
                'required' => true
            ),
        )
    );
}
