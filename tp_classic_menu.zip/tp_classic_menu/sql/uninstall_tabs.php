<?php

/**
 * @author     Konstantinos A. Kogkalidis <konstantinos@tapanda.gr>
 * @copyright  2018 tapanda.gr <https://tapanda.gr/el/>
 * @license    Single website per license
 * @version    1.0
 * @since      1.0
 */

$idtabs = array();

$idtabs[] = Tab::getIdFromClassName('AdminClassicMenu');
$idtabs[] = Tab::getIdFromClassName('AdminClassicMenuCategories');
