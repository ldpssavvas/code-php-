<?php

/**
 * @author     Konstantinos A. Kogkalidis <konstantinos@tapanda.gr>
 * @copyright  2018 tapanda.gr <https://tapanda.gr/el/>
 * @license    Single website per license
 * @version    1.0
 * @since      1.0
 */

$sql = array();

$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'tp_classic_menu_category` (
  `id_tp_classic_menu_category` int(11) UNSIGNED NOT NULL auto_increment,
  `category_id` int(11) UNSIGNED NOT NULL,
  `position` int(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id_tp_classic_menu_category`)
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';

$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'tp_classic_menu_category_product` (
  `category_id` int(11) UNSIGNED NOT NULL,
  `product_id` int(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`category_id`,`product_id`)
) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';


































$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'tp_media_category` (
	`id_tp_media_category` int(11) UNSIGNED NOT NULL auto_increment,
	`parent` int(11) UNSIGNED NOT NULL,
	`link_rewrite` varchar(150) NOT NULL UNIQUE,
  PRIMARY KEY (`id_tp_media_category`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8' ;

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'tp_media_category_lang` (
  `id_tp_media_category` int(11) UNSIGNED NOT NULL,
  `id_lang` int(11) UNSIGNED NOT NULL,
  `meta_title` varchar(150) NOT NULL,
  PRIMARY KEY (`id_tp_media_category`,`id_lang`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8' ;

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'tp_slideshow` (
  `id_tp_slideshow` int(11) UNSIGNED NOT NULL auto_increment,
  `status` tinyint(1) DEFAULT 1,
  `private` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id_tp_slideshow`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8' ;

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'tp_slideshow_lang` (
  `id_tp_slideshow` int(11) UNSIGNED NOT NULL,
  `id_lang` int(11) UNSIGNED NOT NULL,
  `meta_title` varchar(150) NOT NULL,
  PRIMARY KEY (`id_tp_slideshow`,`id_lang`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8' ;

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'tp_slideshow_relations` (
  `id_tp_slideshow` int(11) UNSIGNED NOT NULL,
  `entity` int(11) UNSIGNED NOT NULL,
  `entity_id` int(11) UNSIGNED NOT NULL,
  `pos` int(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id_tp_slideshow`,`entity`,`entity_id`,`pos`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8' ;
