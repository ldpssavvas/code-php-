<?php

/**
 * @author     Konstantinos A. Kogkalidis <konstantinos@tapanda.gr>
 * @copyright  2018 tapanda.gr <https://tapanda.gr/el/>
 * @license    Single website per license
 * @version    1.0
 * @since      1.0
 */

$sql = array();

$sql[] = 'DROP TABLE IF EXISTS  `'._DB_PREFIX_.'tp_classic_menu_category`';
$sql[] = 'DROP TABLE IF EXISTS  `'._DB_PREFIX_.'tp_classic_menu_category_product`';
