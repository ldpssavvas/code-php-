<?php

/**
 * @author     Konstantinos A. Kogkalidis <konstantinos@tapanda.gr>
 * @copyright  2018 tapanda.gr <https://tapanda.gr/el/>
 * @license    Single website per license
 * @version    1.0
 * @since      1.0
 */

$tabvalue = array(
    array(
        'class_name' => 'AdminClassicMenuCategories',
        'id_parent' => $tab_id,
        'module' => 'tp_classic_menu',
        'name' => 'Κατηγορίες',
    )
);
