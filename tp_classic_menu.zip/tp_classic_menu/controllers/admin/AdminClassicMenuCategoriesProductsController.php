<?php

/**
 * @author     Konstantinos A. Kogkalidis <konstantinos@tapanda.gr>
 * @copyright  2018 tapanda.gr <https://tapanda.gr/el/>
 * @license    Single website per license
 * @version    1.0
 * @since      1.0
 */

require_once _PS_MODULE_DIR_.'tp_skroutz_spy/tp_skroutz_spy.php';

class AdminSkroutzSpyLinksController extends ModuleAdminController
{
    public function __construct()
    {
        $this->lid = Context::getContext()->language->id;

        $this->fw = new tp_skroutz_spy();

        $this->table = 'tp_skroutz_link';
        $this->className = 'SkroutzSpyLink';
        $this->bootstrap = true;

        parent::__construct();

        $this->addRowAction('edit');
        $this->addRowAction('delete');

        $this->bulk_actions = array(
            'delete' => array(
                'text' => $this->l('Delete selected'), 
                'confirm' => $this->l('Delete selected items?')
            ),
            'enableSelection' => array('text' => $this->l('Enable selection')),
            'disableSelection' => array('text' => $this->l('Disable selection'))
        );
        
        $this->fields_list = array(
            'id_tp_skroutz_link' => array(
                'title' => $this->l('ID'),
                'width' => 30,
                'type' => 'text'
            ),
        );
    }

    public function renderForm()
    {
        $this->fields_form = array(
            'input' => array(
                array(
                    'type' => 'text',
                    'label' => $this->l('Link'),
                    'name' => 'link',
                    'required' => true
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Product ID'),
                    'name' => 'product_id',
                    'required' => true
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('IPA'),
                    'name' => 'ipa'
                )
            ),
            'submit' => array('title' => $this->l('Save')),
        );

        $this->fields_form['submit'] = array(
            'title' => $this->l('Save')
        );
        
        return parent::renderForm();
    }
}
