<?php

/**
 * @author     Konstantinos A. Kogkalidis <konstantinos@tapanda.gr>
 * @copyright  2018 tapanda.gr <https://tapanda.gr/el/>
 * @license    Single website per license
 * @version    1.0
 * @since      1.0
 */

require_once _PS_MODULE_DIR_.'tp_classic_menu/tp_classic_menu.php';

class AdminClassicMenuCategoriesController extends ModuleAdminController
{
    public function __construct()
    {
        $this->lid = Context::getContext()->language->id;

        $this->fw = new tp_classic_menu();

        $this->table = 'tp_classic_menu_category';
        $this->className = 'ClassicMenuCategory';
        $this->bootstrap = true;

        parent::__construct();

        $this->addRowAction('edit');
        $this->addRowAction('delete');

        $this->bulk_actions = array(
            'delete' => array(
                'text' => $this->l('Delete selected'), 
                'confirm' => $this->l('Delete selected items?')
            ),
            'enableSelection' => array('text' => $this->l('Enable selection')),
            'disableSelection' => array('text' => $this->l('Disable selection'))
        );
        
        $this->fields_list = array(
            'id_tp_classic_menu_category' => array(
                'title' => $this->l('ID'),
                'width' => 30,
                'type' => 'text'
            )
        );
    }


    public function initContent()
    {
        //Get action
        $this->action = Tools::getValue('action');

        if($this->action == 'ajaxProcessCategorySearch')
        {
            $this->ajax = true;

            $this->q = Tools::getValue('q');

            $this->ajaxProcessCategorySearch();
        }

        $link = $this->fw->getAdminLink('ClassicMenuCategories');

        //We get the category relations
        $sql = $this->fw->selectQuery('tp_classic_menu_category`');

        $fields = [];
        $fields[0] = 'category_id';

        //We get the actual categories based on the relations
        $in = $this->fw->tableToCSV($sql,$fields);

        if($in != '()')
        {
            //We get the categories raw results
            $sql = $this->fw->selectQueryLang('category',$this->lid,' AND t.`id_category` IN '.$in);

            //We assign the relation ID to the category
            $categories = $this->fw->getCategoriesWithMenuIDs($sql);
        }else
        {
            $categories = [];
            //$categories = '[]';
        }

        $this->context->smarty->assign(array(
            'pure_link' => $link,
            'back_link' => $link,
            'categories' => $categories
        ));

        //We detect if its form or list
        $form = $this->fw->listOrForm($_SERVER['REQUEST_URI']);

        if($form == 1)
        {
            $this->setTemplate('modules/tp_classic_menu/categories/form.tpl');
        }else
        {
            $this->setTemplate('modules/tp_classic_menu/categories/list.tpl');
        }
    }

    public function ajaxProcessCategorySearch()
    {
        //We sanitize the input
        if(Validate::isGenericName($this->q))
        {
            $categories = $this->fw->selectQueryLang('category',$this->lid,' AND `name` LIKE "%'.$this->q.'%"');

            $this->context->smarty->assign(array(
                'categories' => $categories
            ));
        }

        die($this->context->smarty->fetch(_PS_MODULE_DIR_.$this->fw->name.'/views/templates/admin/ajax/categories/search_results.tpl'));
    }
}
