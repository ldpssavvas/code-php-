<?php

/**
 * @author     Konstantinos A. Kogkalidis <konstantinos@tapanda.gr>
 * @copyright  2018 tapanda.gr <https://tapanda.gr/el/>
 * @license    Single website per license
 * @version    1.0
 * @since      1.0
 */

require_once _PS_MODULE_DIR_.'tp_classic_menu/tp_classic_menu.php';

class tp_classic_menuProductsModuleFrontController extends ModuleFrontController
{
	public $context;
	public $cid;

	public function init()
	{
		parent::init();

		$this->fw = new tp_classic_menu();

		$this->ajax = true;

		$this->cid = (int)Tools::getValue('cid');

		$this->context = Context::getContext();
	}

	public function initContent()
	{
		$this->lid = $this->context->language->id;

		parent::initContent();

		$products = $this->fw->getProducts($this->cid,$this->lid);

        $this->context->smarty->assign(array(
            'products' => $products
        ));

        $html = '';
        foreach($products as $p)
        {
        	//We open the list
        	$html .= '<div class="product col-lg-6"><a href="'.$p['link'].'">';

        	//We add the image
        	$html .= '<div class="col-lg-3"><img src="../'.$p['image'].'-small_default/'.$p['link_rewrite'].'.jpg"></div>';

        	//We add the name and the price
        	$html .= '<div class="col-lg-9"><p class="name">'.$p['name'].'<span class="price">'.$p['price'].' €</span></p>'.$p['description_short'].'</div>';

        	//We close the list
        	$html .= '</a></div>';
        }

       	$this->ajaxDie($html);
	}
}